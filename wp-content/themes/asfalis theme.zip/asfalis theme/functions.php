<?php 

function aes_files() {
	wp_enqueue_script('aes_main_js', get_theme_file_uri('/js/scripts-bundled.js'), NULL, microtime(), true);
	wp_enqueue_style( 'custom-font-style', '//fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i|Roboto:100,300,400,400i,700,700i' );
	wp_enqueue_style( 'font-awsome', '//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' );
	wp_enqueue_style( 'aes_main_style', get_template_directory_uri() . '/style1.css', NULL, microtime() );
}

add_action( 'wp_enqueue_scripts', 'aes_files' );


function aes_features() {
	register_nav_menu('headerMenuLocation', 'Header Menu Location');
	register_nav_menu('footerLocationOne', 'Footer Location One');
	register_nav_menu('footerLocationTwo' , 'Footer Location Two');
	add_theme_support('title-tag');
}

add_action('after_setup_theme', 'aes_features');

?>

